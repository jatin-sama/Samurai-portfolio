# JAMTIN portfolio

Cinematic WebGL portfolio (Three.js + GSAP from CDN). Plain HTML/CSS/JS, no framework, no dependencies.

## Structure
    src/
      index.html        page template (markers like <!--@js js/05-scene-main.js--> mark where files are placed)
      css/              stylesheets, numbered in load order
      js/               scripts, numbered in load order (order matters: models and audio load before scenes)
      data/*.b64        embedded 3D models, textures (gzip/base64), read at runtime via their element ids
      public/           copied as-is to the site root (favicon, og-image, robots, sitemap, 404)
    scripts/
      build.mjs         assembles dist/ as one self-contained index.html (the original loading behaviour); --split is an opt-in experiment
      verify.mjs        proves the source still rebuilds the original single-file site byte for byte
      dev.mjs           build + local server on :3000
    tests/baseline.sha256   hash of the original v24 single file
    vercel.json         build, headers, caching

## Commands
    npm run dev           build and serve at http://localhost:3000 (visit /__rebuild after edits)
    npm run build         production build -> dist/ (lean: small index.html + src/data payloads as cached files in assets/data/, CDN libraries)
    npm run build:inline  the old single 26 MB index.html -> dist-single/ (what `verify` checks)
    npm run build:split   experimental build -> dist-split/ (external hashed files, self-hosted libraries)
    npm run verify        check the source still equals the baseline

`verify` will fail after you intentionally edit anything under src/. That is expected: run
`npm run verify` and copy the hash it prints for dist-verify/index.html into tests/baseline.sha256 (the analytics tag is not part of that hash).

## Deploy (Vercel)
Import the repo. Framework Preset: Other (vercel.json already sets the build command and the dist/ output). Add the jamtin.me domain.

## Split build (experimental, NOT used for production)
The production build keeps CSS, JS and model data inline, exactly like the original site, because the split version did not give a better loading experience.
`npm run build:split` is kept only for future experiments. Details of what it does:

### Model payloads
In the normal build each `src/data/*.b64` payload becomes `assets/data/<name>.<hash>.js`. The placeholder `<script type="text/plain" id="...">` stays where it was and a
parser-blocking script right after it fills in the identical text, so every consumer sees the same content at the same moment. index.html is ~0.4 MB instead of 23.5 MB.
Files download in parallel and are cached for a year. 

### Self-hosted libraries
The split build downloads Three.js and GSAP from cdnjs into dist/vendor/ and rewrites the script tags (cached for a year).
If a download fails, the build prints a WARN line and keeps the CDN link.

## Sound guide behaviour
First visit: full intro. Returning visitors (stored in localStorage `jamtin_kg_seen`): a shorter, different line, lighter dim, auto-hides after 11 s.
After 3 visits she no longer appears. Clear the key to test again.

## Polish layer
`src/css/08-polish.css` + `src/js/23-polish.js`: custom cursor (fine pointers only; states link, hold, drag, text; touch gets a tap ripple), magnetic buttons,
press and focus feedback, hover/click sounds through JSND (only while sound is on), and a slow-breathing ember/moon glow (`#kglow`). Vignette and grain already existed (`.vig`, `#fx`).
Remove the `08`/`23` markers in `src/index.html` (and the `#kglow`/`#kc` elements) to switch it all off.

## Analytics
Cookieless, no personal data, provider-agnostic (`src/js/00-analytics.js`). Default: **Vercel Web Analytics** (`analytics.config.json` -> `"provider": "vercel"`; turn it on once in the Vercel dashboard: Project > Analytics > Enable, then redeploy). Change it in `analytics.config.json` or with Vercel env vars
`ANALYTICS_PROVIDER` (`vercel` | `umami` | `goatcounter` | `plausible` | `ga4`), `ANALYTICS_ID`, optional `ANALYTICS_SRC` (self-hosted script URL). Env vars win over the file.
- vercel: no ID needed; loads `/_vercel/insights/script.js` (only exists on Vercel; page views are free, custom events need a plan that includes them).
- umami: ID = Website ID. goatcounter: ID = your code (the `xxx` in xxx.goatcounter.com). plausible: ID = domain. ga4: ID = `G-XXXXXXXXXX` (sets cookies, needs a consent banner).
- Check it: open the site with `?jtdebug` to log events to the console. Visit `?notrack=1` once to exclude your own browser (`?notrack=0` undoes it). Do Not Track is respected.
- Events: `session_start` (device, network, referrer), `loader_slow`, `loader_done` (time bucket, `failopen`=1 when the 16 s limit hit), `loader_exit` (progress when they left), `scene_ready`, `fallback_mode` (no 3D),
  `fox_shown/accept/decline`, `sound` on/off, `begin_hold_start`, `journey_begin`, `chapter` (about, projects, skills, experience, contact), `project_open`, `final_gate_open`,
  `contact_start/submit/sent/fail`, `link` (mailto, resume, external host), `email_copy`, `engaged` (30 s, 2 min), `session_end` (where they stopped), `js_error`, `webgl_lost`.

## Performance and reliability
- `src/js/00-performance.js`: on 100 Hz+ screens the animation loop is capped (about 72-82 fps instead of 165); if the frame rate stays under ~42 fps the 3D resolution steps down
  (1.5, 1.25, 1, 0.85, 0.7) and the glow layer is dropped. It never raises quality again in the same session. Open the site with `?jtdebug` to see its decisions in the console; `__perf.limited()` and `__perf.level()` show the state.
- Three.js and GSAP load from cdnjs, then jsdelivr, then `/vendor/*.min.js` (copied during the Vercel build when the download works). A visitor whose network blocks one CDN still gets the 3D scene.
- If a browser lacks WebGL or decompression support the site falls back gracefully (plain page / classic slash instead of the scythe cinematic).
- Build id: `document.querySelector('meta[name=jt-build]').content` in the console should print `inline-2026-11-13` on the live site. If it prints nothing or a different value, an older deploy is live.

## Diagnostics
Open the live site with `?diag` to get an on-screen report (GPU name and whether it is software rendering, refresh rate, live fps, reduced-motion, library/feature checks, recent console warnings) with a Copy button.
Test switches, combinable: `&pr=1` (force 3D resolution), `&noperf` (disable frame cap and auto quality), `&nolimit`, `&noglow`, `&nocursor`. Example: `jamtin.me/?diag&pr=1`.
Nothing runs for normal visitors.

## Editing guide
- Project cards, links and copy: src/js/06-content-projects.js
- Sound guide (fox): src/css/07-sound-guide.css and src/js/22-sound-guide.js, markup is in src/index.html (#kg)
- Hero scythe size: the `s=1.25*...` line in src/js/05-scene-main.js
- Keep script order in src/index.html; do not reorder markers.
- Replay the sound guide: clear localStorage key `jamtin_kg_seen`.

## Known follow-ups
Large base64 blobs still live inside src/js/07-audio-engine.js (sound samples) and src/js/06-content-projects.js (project images).
Moving them to real files would shrink the JS considerably but means changing how they are loaded, so it was left alone.

## Lean loading (v25.1)
The home page needs samurai, scythe, torii and lantern, so those four payloads are 'eager': they download in parallel from the first moment, the loader bar shows real download progress, and the scene scripts (marked `data-jt-run` in the build) only start once they have arrived. The oni gate and blood moon are lazy (background fetch after the home page is up, via `window.__jtData(id)`). Logic: `src/js/00-data.js`. The loader no longer gives up after 16 s while the download is still progressing (it waits up to 3 min, then falls back to the plain page).

## Weather timing
`src/js/05-scene-main.js` (`WX`): the first rain starts `FIRST_RAIN` (10) seconds after the intro zoom ends and shows a small `雨 · the rain begins` toast once. After that it loops 18 s sakura / 40 s storm. `?storm` previews the storm immediately.

## Storm details (v25.3)
- Rain on the glass: `src/js/24-storm-glass.js` + `src/css/09-storm-glass.css` (`#drops` canvas). Pre-rendered droplet sprites bead up, slide in stop-and-go bursts with trails and tiny beads, and catch the light on every lightning strike. Stops itself outside the storm.
- Only every 2nd-3rd strike (random) also lights the hero scythe: a cold rim light from behind, computed inside the scythe's own shader so it follows the metal and texture (`window.__bladeFlash` -> `uFl` in `buildHeroScythe`, `05-scene-main.js`). The moon-tap bolt always does.
- First storm: one short phone vibration (once per visit, via `HAP`).
- Hidden surprise: tap/click the moon on the home screen. It turns blood red for ~4 s (and calls a bolt during the storm). Tracked as `moon_egg`.
- `src/public/404.html`: rainy page with a tap-for-lightning moon; respects reduced motion.

## Story order (v26, castle)
Hero, About, Projects (night bridge, castle reveal at ~85% scroll, the oni gate is the castle's closed outer gate), Experience (the gate opens; a red arched
bridge, a covered wooden bridge and a short "what's next" bridge over the moat; camera rises to the keep door then climbs to the roof), Skills (the fall through
the keep, floor by floor, to the red doors), Contact (the final gate). Chapter numbers: Experience III, Skills IV.
- Page order lives in: `VIEWS`/`NUM` in `js/06-content-projects.js`, `CH` in `js/13-cinematic-layer.js`, the nav in `index.html`, and the hand-offs
  (`finish()` in `js/10-gate-lanterns.js` -> #skills, `#skgo` in `js/14-skills-dive.js` -> #contact). Music is keyed by view name, so it follows the order automatically.
- `js/04b-model-castle.js`: `window.__castle({glowMap,k})` -> Group. Data: `data/castle.b64` + `data/castle-tex.b64` (lazy, like the oni gate, ~0.84 MB total).
  Rebuild the model from a GLB with `scripts/castle/1..3` (python3 + numpy + Pillow; vertex clustering that keeps UV islands, cell 0.015 -> 44k triangles).
- Projects reveal: `reveal()` in `js/15-projects-crossing.js` (fog density, mist sprites, thunder, castle `look()`/`lights()`, moon rise). Tuning: `CASTLE_S/Y/Z`, `GS` (stop distance in front of the gate).
- Experience: layout constants at the top of `js/11-experience-ascent.js` (`B1`, `B2`, `B3`, `CAST_*`); `KEY` maps the walk value to the camera path.
